Se debe colocar las torres en los cuadros de la matriz
Este juego no tiene la función de guardado y tampoco cambia la velocidad de disparo de las torres.
Por útilmo quedo incompleto lo de best scores